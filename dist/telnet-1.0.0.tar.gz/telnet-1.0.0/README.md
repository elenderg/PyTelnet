# telnet
## A small package for sending and recieving commands per tcp
